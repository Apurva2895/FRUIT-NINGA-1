var PLAY = 1;
var END = 0;
var gameState = 1;

var sword, swordImage;
var fruit,fruit1,fruit2,fruit3,fruit4;
var alien,alienImage;
var fruitGroup,enemyGroup;
var SwordSound,GameOverSd;
var gameover,gameoverS;


var score = 0;

function preload(){
  swordImage = loadImage("sword.png"); 
  fruit1 = loadImage("fruit1.png");
  fruit2 = loadImage("fruit2.png");
  fruit3 = loadImage("fruit3.png");
  fruit4 = loadImage("fruit4.png");
  alienImage = loadAnimation("alien1.png","alien2.png");
  SwordSound = loadSound("knifeSwooshSound.mp3");
  gameover = loadImage("gameover.png");
  gameoverS =loadSound("gameover.mp3");
}

function setup(){
  createCanvas(500,500);
  //creating sword
  sword = createSprite(60,200,20,20);
  sword.addImage(swordImage);
  sword.scale = 0.6;
  
  fruitGroup = new Group();
  enemyGroup = new Group();
}

function draw(){
  background("blue");
  textSize(20);
  fill(220);
  text("Score:"+score,400,40)
  drawSprites();
  
  if(gameState===PLAY){
    sword.y = World.mouseY;
    sword.x = World.mouseX;  
    
    //Incresing score if sword touching fruit
    if(fruitGroup.isTouching(sword)){
     SwordSound.play();
      fruitGroup.destroyEach();
      score = score+2;
    }
    
    
    
    
    
    
    fruits();
    monster();
    
    if(sword.isTouching(enemyGroup)){
      gameoverS.play();
      enemyGroup.destroyEach();
      gameState= END;
    }
  }
  
  if(gameState===END){
    
    sword.addImage(gameover);
    sword.scale=2;
    sword.x=250;
    sword.y=250;
    fruitGroup.SetvelocityXEach = 0;
    fruitGroup.setlifetimeEach = -1;
    enemyGroup.setlifetimeEach = -1;
  }
  
  
  
}

function fruits(){
  if(World.frameCount%60===0){
    fruit = createSprite(400,200,20,20);
    fruit.scale = 0.2;
    //fruit.debug=true;
    r = Math.round(random(1,4));
    if(r==1){
      fruit.addImage(fruit1);
    } else if(r==2){
      fruit.addImage(fruit2);
    } else if(r==3){
      fruit.addImage(fruit3);
    } else{
      fruit.addImage(fruit4);
    }
    
    fruit.y=Math.round(random(50,340));
    
    fruit.velocityX = -7;
    fruit.setlifetime = 80;
    
    fruitGroup.add(fruit);
  }
}


function monster(){
  if(World.frameCount%120===0){
    alien = createSprite(400,200,20,20);
    alien.scale=1.4;
    alien.addAnimation("moving",alienImage)
    enemyGroup.add(alien);
    alien.y=Math.round(random(100,300));
    alien.velocityX = -8
    monster.setlifetime=50;
    
  }
}